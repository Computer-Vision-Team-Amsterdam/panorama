# pylint: disable=C0114
__version__ = "0.2.2"
